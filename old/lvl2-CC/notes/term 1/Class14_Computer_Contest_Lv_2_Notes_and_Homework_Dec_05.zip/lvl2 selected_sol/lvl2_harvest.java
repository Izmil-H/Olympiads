import java.util.*;
public class Test {
	public static void main(String [] args){
		Scanner in = new Scanner ( System.in );
		int N=in.nextInt(), M = in.nextInt(), ans=N+1; long K = in.nextLong();
		int [] dif = new int [N+2];
		for(int i=0; i<M; i++){
			int a = in.nextInt(), b = in.nextInt();
			dif[a] -= 1; dif[b+1] += 1;
		}
		for(int i=1; i<=N; i++){
			dif[i] += dif[i-1];
		}
		long [] sum = new long [N+2];
		for(int i=1; i<=N; i++){
			dif[i] += M;  sum[i] = sum[i-1] + dif[i];
		}
		for(int l=0, r=1; r<=N; r++){
			while( l <= r && sum[r] - sum[l] >= K){
				ans = Math.min(ans, r-l); l++;
			}
		}
		if( ans > N ) System.out.println(-1);
		else System.out.println(ans);
	}
}