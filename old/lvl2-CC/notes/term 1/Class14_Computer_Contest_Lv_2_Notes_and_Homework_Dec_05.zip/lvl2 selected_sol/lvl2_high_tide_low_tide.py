n = int(input())
l = list(map(int, input().split()))
l.sort()
lowertl = l[0 : len(l)//2]
highertl = l[(len(l)+1)//2: ]
ans = []
if len(l) % 2 != 0:
    lowertl.append(l[len(l)//2])
for i in range(len(highertl)):
    ans.append(lowertl[-i-1])
    ans.append(highertl[i])
if len(lowertl) != len(highertl):
    ans.append(lowertl[0])
    
for i in ans:
    print(i, end=' ')
print()