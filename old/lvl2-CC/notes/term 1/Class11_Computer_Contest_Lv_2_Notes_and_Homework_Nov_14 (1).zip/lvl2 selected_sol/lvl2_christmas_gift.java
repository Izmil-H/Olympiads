import java.util.*;
import java.io.*;
public class homework {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException{
		int n = readInt(), tot = readInt();
		List<pair> item = new ArrayList();
		for(int i=0; i<n; i++)
			item.add(new pair(readInt(), readInt()));
		int ans = 0;
		for(int i=0; i<n; i++) {
			item.get(i).p /= 2;
			ans = Math.max(ans, countItems(item, tot));
			item.get(i).p *= 2;
		}
		System.out.println(ans);
	}
	static int countItems(List<pair> item, int rem) {
		List<pair> tmp = new ArrayList(item);
		Collections.sort(tmp);
		int cnt = 0;
		for(pair e: tmp) {
			if(rem >= e.p + e.s) {
				cnt ++;  rem -= e.p + e.s;
			}else break;
		}
		return cnt;
	}
	static class pair implements Comparable<pair>{
		int p, s;
		pair(int p0, int s0) { p = p0; s = s0; }
		public int compareTo(pair x) { return Integer.compare(p + s, x.p + x.s); }
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}