import math
x, y, a, b = map(int, input().split())
lcm = a*b//math.gcd(a, b)
x -= 1
print( (y//a + y//b - y//lcm) - (x//a + x//b - x//lcm) )