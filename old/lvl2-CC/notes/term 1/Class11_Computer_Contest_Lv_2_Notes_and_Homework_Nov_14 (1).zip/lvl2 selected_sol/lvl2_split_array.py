n = int(input())
lst = list(map(int, input().split()))
tot = sum(lst)
ans, s1 = tot, 0
for i in lst:
    s1 += i
    s2 = tot - s1
    ans = min(ans, abs(s1 - s2))
print(ans)