#include <bits/stdc++.h>
using namespace std;
const int MM = 1e6+2;
string s; int psa[26][MM], q; char c;
int main(){
    getline(cin, s);
    for(int i=1; i<=s.size(); i++){
        char c = s[i-1];
        for(int j=0; j<26; j++){
            psa[j][i] = psa[j][i-1];
        }
        if(c != ' ') psa[c-'a'][i]++;
    }
    cin >> q;
    for(int i=1, l, r; i<=q; i++){
        cin >> l >> r >> c;
        cout << psa[c-'a'][r] - psa[c-'a'][l-1] << "\n";
    }
}