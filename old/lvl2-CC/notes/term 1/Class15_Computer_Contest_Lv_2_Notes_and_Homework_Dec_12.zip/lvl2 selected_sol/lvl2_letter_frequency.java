import java.util.*;
import java.io.*;

public class Main {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException {
		String s = readLine();
		int Q = readInt(), psa[][] = new int[26][s.length() + 1];
		for(int i=1; i<=s.length(); i++) {
			char c = s.charAt(i-1) ;
			for(int j=0; j<26; j++) psa[j][i] = psa[j][i-1];
			if(c != ' ') psa[c-'a'][i]++;
		}
		for(int i=1; i<=Q; i++) {
			int l = readInt(), r = readInt(), c = readCharacter() - 'a';
			System.out.println(psa[c][r] - psa[c][l-1]);
		}
	}
	static String next() throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}

	static long readLong() throws IOException {
		return Long.parseLong(next());
	}

	static int readInt() throws IOException {
		return Integer.parseInt(next());
	}

	static double readDouble() throws IOException {
		return Double.parseDouble(next());
	}

	static char readCharacter() throws IOException {
		return next().charAt(0);
	}

	static String readLine() throws IOException {
		return br.readLine().trim();
	}
}