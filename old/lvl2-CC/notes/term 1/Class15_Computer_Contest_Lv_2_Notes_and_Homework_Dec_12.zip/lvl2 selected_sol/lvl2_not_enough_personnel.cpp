#include <bits/stdc++.h>
using namespace std;
struct veteran {
    string name; int s, id;
}v[500];
int n, q;
bool cmp(veteran x, veteran y){
    return x.s < y.s || (x.s == y.s && x.id < y.id);
}
int main(){
    cin >> n;
    for(int i=0; i<n; i++){
        cin >> v[i].name >> v[i].s; v[i].id = i;
    }
    sort(v, v+n, cmp);
    cin >> q;
    for(int i=0, skill, d, j; i<q; i++){
        cin >> skill >> d;
        for(j=0; j<n; j++){
            if(v[j].s >= skill && v[j].s <= skill+d){
                cout << v[j].name << "\n";
                break;
            }
        }
        if(j == n) cout << "No suitable teacher!\n";
    }
}