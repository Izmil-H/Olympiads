#include <bits/stdc++.h>
using namespace std;
const int MM = 1e5+3;
int T, k, a, b, cnt[MM]; vector<int> factor[MM];
int main(){
    cin.sync_with_stdio(0); cin.tie(0);
    for(int i=1; i<MM; i++){
        for(int j=i; j<MM; j+=i){ cnt[j]++; }
        factor[cnt[i]].push_back(i);
    }
    for(cin >> T; T > 0; T--){
        cin >> k >> a >> b;
        cout << upper_bound(factor[k].begin(), factor[k].end(), b)
               - lower_bound(factor[k].begin(), factor[k].end(), a) << "\n";
    }
}