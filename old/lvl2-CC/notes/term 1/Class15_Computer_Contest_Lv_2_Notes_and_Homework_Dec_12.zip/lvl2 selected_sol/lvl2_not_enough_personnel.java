import java.util.*;
import java.io.*;
public class homework {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException{
		int n = readInt(), s[] = new int[n]; String name[] = new String[n];
		for(int i=0; i<n; i++) {
			name[i] = next(); s[i] = readInt();
		}
		int q = readInt();
		for(int i=0; i<q; i++) {
			int skill = readInt(), d = readInt(), best = Integer.MAX_VALUE; String ans="";
			for(int j=0; j<n; j++) {
				if(skill <= s[j] && s[j] <= skill+d) {
					if(s[j] - skill < best) {
						best = s[j] - skill;
						ans = name[j];
					}
				}
			}
			if(best == Integer.MAX_VALUE) System.out.println("No suitable teacher!");
			else System.out.println(ans);
		}
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}