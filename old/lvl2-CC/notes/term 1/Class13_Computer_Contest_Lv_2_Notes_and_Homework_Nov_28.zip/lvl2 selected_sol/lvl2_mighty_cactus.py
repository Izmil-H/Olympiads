import sys
input = sys.stdin.readline
n, m, k = map(int, input().split())
t = [0]*k
pct = [0.0]*k
for i in range(k):
    t[i], pct[i] = map(int, input().split())
    pct[i] = (100 - pct[i])/100
maxT = int(2e6)
last = 0
dif = [0]*(maxT + 2)
for i in range(m):
    s, len, x = map(int, input().split())
    dif[s] += x
    dif[s + len] -= x
    last = max(last, s + len)
for i in range(last + 1):
    if i > 0 :
        dif[i] += dif[i-1]
    if dif[i] == 0:
        continue
    mi = dif[i]
    for j in range(k):
        if t[j] >= dif[i]:
            mi = 0
            break
        else:
            mi = min(mi, (dif[i] - t[j])*pct[j])
    n -= mi
    if n <= 0:
        break
if n <= 0:
    print('Act Like A Cactus.')
else:
    print('{0:.2f}'.format(n))