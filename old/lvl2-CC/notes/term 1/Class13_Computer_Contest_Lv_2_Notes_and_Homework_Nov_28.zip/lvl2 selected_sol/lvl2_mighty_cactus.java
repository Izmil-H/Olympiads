import java.util.*;
import java.io.*;
public class homework {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException{
		double n = readDouble(); int m = readInt(), k = readInt();
		int t[] = new int[k]; double pct[] = new double[k];
		for(int i=0; i<k; i++) {
			t[i] = readInt(); pct[i] = readDouble();  pct[i] = (100.0 - pct[i])/100.0;
		}
		int maxT = (int)2e6, dif[] = new int[maxT + 2];
		for(int i=1; i<=m; i++) {
			int s = readInt(), len = readInt(), x = readInt();
			dif[s] += x;  dif[s+len] -= x;
		}
		for(int i=0; i<=maxT; i++) {
			if(i > 0) dif[i] += dif[i-1];
			if(dif[i] == 0) continue;
			double min = dif[i]; 
			for(int j=0; j<k; j++) {
				if(t[j] >= dif[i]) { min = 0; break; }
				else { min = Math.min(min, (dif[i]-t[j])*pct[j]); }
			} 
			n -= min;
			if(n <= 0) { System.out.println("Act Like A Cactus."); return; }
		}
		System.out.printf("%.2f\n", n);
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}