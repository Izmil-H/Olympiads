import java.util.*;
public class test{
	public static void main(String [] args){
		Scanner in = new Scanner(System.in);
		double H = in.nextDouble(); int D = in.nextInt(), E = in.nextInt();
		int dif[] = new int[1002], s[] = new int[D], a[] = new int [D];
		for(int i=0; i<D; i++){ a[i] = in.nextInt(); s[i] = in.nextInt(); }
		for(int i=0; i<E; i++){
			int t = in.nextInt(), len = in.nextInt(), val = in.nextInt();
			dif[t] += val;  dif[t + len] -= val;
		}
		for(int i=0; i<=1000; i++){
			if(i > 0) dif[i] += dif[i-1];
			if(dif[i] > 0){
				double damage = dif[i];
				for(int j=0; j<D; j++){
					if(s[j] >= dif[i]) { damage = 0; break; }
					else damage = Math.min(damage, (dif[i] - s[j]) * (100.0-a[j])/100.0);
				}
				H -= damage;
				if(H <= 0) { System.out.println("DO A BARREL ROLL!"); return; }
			}
		}
		System.out.printf("%.2f", H);
	}
}