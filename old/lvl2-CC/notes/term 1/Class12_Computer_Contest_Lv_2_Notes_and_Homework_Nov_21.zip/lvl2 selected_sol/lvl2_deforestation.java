import java.util.*;
import java.io.*;
public class homework {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException{
		int n = readInt(), psa[] = new int[n];
		psa[0] = readInt();
		for(int i=1; i<n; i++) {
			psa[i] = readInt() + psa[i-1];
		}
		int q = readInt();
		for(int i=1; i<=q; i++) {
			int x = readInt(), y = readInt();
			if(x == 0) System.out.println(psa[y]);
			else System.out.println(psa[y] - psa[x-1]);
		}
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}