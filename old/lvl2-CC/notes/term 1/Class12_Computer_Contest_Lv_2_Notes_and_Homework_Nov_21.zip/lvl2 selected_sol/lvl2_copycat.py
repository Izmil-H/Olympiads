for t in range(5):
    s, length = input(), 0
    for i in range(1, len(s)):
        if s[:i] == s[-i:]:
            length = i
    print(s + s[length:])