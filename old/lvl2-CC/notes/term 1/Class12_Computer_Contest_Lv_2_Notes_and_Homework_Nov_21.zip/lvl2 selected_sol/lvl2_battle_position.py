import sys
input = sys.stdin.readline
station, mi, wave = int(input()), int(input()), int(input())
dif = [0]*(station+2)
for i in range(wave):
    x, y, z = map(int, input().split())
    dif[x] += z
    dif[y+1] -= z
ans = 0
for i in range(1, station+1):
    dif[i] += dif[i-1]
    if dif[i] < mi:
        ans += 1
print(ans)