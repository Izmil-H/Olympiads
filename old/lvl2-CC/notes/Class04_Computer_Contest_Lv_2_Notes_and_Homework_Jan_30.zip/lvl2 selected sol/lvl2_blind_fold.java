import java.util.*;
import java.io.*;
public class homework {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static PrintWriter pr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException {
        int R = readInt(), C = readInt(); char g[][] = new char[R][C];
        for(int i=0; i<R; i++)
        	g[i] = readLine().toCharArray();
        int M = readInt(); char a[] = new char[M];
        for(int i=0; i<M; i++) a[i] = readLine().charAt(0);
        int dir[][] = {{-1, 0}, {0, 1}, {1, 0}, {0, -1}};
        for(int r=0; r<R; r++) {
        	for(int c=0; c<C; c++) {
        		if(g[r][c]=='X') continue;
        		for(int d=0; d<4; d++) {
        			int curR = r, curC = c, curD = d; boolean flag = true;
        			for(int i=0; i<M; i++) {
        				if(a[i] == 'F') { curR += dir[curD][0]; curC += dir[curD][1]; }
        				if(a[i] == 'R') curD = (curD+1)%4;
        				if(a[i] == 'L') curD = (curD-1+4)%4;
        				if(curR < 0 || curR >= R || curC < 0 || curC >= C || g[curR][curC] == 'X') {
        					flag = false; break;
        				}
        			}
        			if(flag) {
        				g[curR][curC] = '*';
        			}
        		}
        	}
        }
        for(int r=0; r<R; r++) System.out.println(g[r]);
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}