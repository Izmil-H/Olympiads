import java.util.*;
import java.io.*;
public class homework {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException{
		for(int t=1; t<=10; t++) {
			String []s = readLine().replaceAll("[()]", "").split(" ");
			Stack<Integer> stk = new Stack();
			for(int i=s.length-1; i>=0; i--) {
				if(Character.isDigit(s[i].charAt(0))) {
					stk.push(Integer.parseInt(s[i]));
				}else {
					int op1 = stk.pop(), op2 = stk.pop();
					if(s[i].equals("+")) stk.push(op1 + op2);
					if(s[i].equals("-")) stk.push(op1 - op2);
					if(s[i].equals("*")) stk.push(op1 * op2);
					if(s[i].equals("q")) stk.push(op1 / op2);
					if(s[i].equals("r")) stk.push(op1 % op2);
				}
			}
			System.out.println(stk.pop());
		}
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}