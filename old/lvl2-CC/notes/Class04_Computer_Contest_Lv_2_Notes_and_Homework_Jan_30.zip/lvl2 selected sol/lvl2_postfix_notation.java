import java.util.*;
import java.io.*;
public class homework {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException{
		String [] s = readLine().split(" ");
		Stack<Double> stk = new Stack();
		for(int i=0; i<s.length; i++) {
			String cur = s[i];
			if(Character.isDigit(cur.charAt(0))) {
				stk.push(Double.parseDouble(cur));
			}else {
				double op2 = stk.pop(), op1 = stk.pop();
				if(cur.equals("+")) stk.push(op1 + op2);
				if(cur.equals("-")) stk.push(op1 - op2);
				if(cur.equals("*")) stk.push(op1 * op2);
				if(cur.equals("/")) stk.push(op1 / op2);
				if(cur.equals("%")) stk.push(op1 % op2);
				if(cur.equals("^")) stk.push(Math.pow(op1, op2));
			}
		}
		System.out.println(stk.pop());
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}