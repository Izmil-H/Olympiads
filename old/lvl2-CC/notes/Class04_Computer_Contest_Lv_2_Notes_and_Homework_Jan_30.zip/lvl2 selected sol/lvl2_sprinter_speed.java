import java.util.*;
import java.io.*;
public class homework {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException{
		int n = readInt(); List<pair> a = new ArrayList();
		for(int i=0; i<n; i++) {
			int t = readInt(), p = readInt();
			a.add(new pair(t, p));
		}
		Collections.sort(a);
		double ans = 0;
		for(int i=1; i<a.size(); i++) {
			ans = Math.max(ans, (double)Math.abs(a.get(i).p - a.get(i-1).p) / (a.get(i).t - a.get(i-1).t));
		}
		System.out.println(ans);
	}
	static class pair implements Comparable<pair>{
		int t, p;
		pair(int t0, int p0) { t= t0; p = p0;}
		public int compareTo(pair x) { return Integer.compare(t, x.t); }
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}