import sys

input = sys.stdin.readline

for _ in range(10):
    str = input().strip()
    List = []
    for i in range(len(str)):
        if str[i] != '(' and str[i] != ')':
            List.append(str[i])
    List = ''.join(List).split(' ')
    stack = []

    for c in List[::-1]:
        if c not in '+-*qr':
            stack.append(int(c))

        else:
            o1 = stack.pop()
            o2 = stack.pop()
            if c == '+':
                stack.append(o1 + o2)
            elif c == '-':
                stack.append(o1 - o2)
            elif c == '*':
                stack.append(o1 * o2)
            elif c == 'q':
                if o1 * o2 < 0:
                    stack.append(-(-o1//o2))
                else:
                    stack.append(o1 // o2)
            elif c == 'r':
                stack.append(o1 % o2)
    print(int(stack.pop()))