#include <iostream>
#include <cstdio>
using namespace std;

int r, c, m, dir[4][2]={{-1,0}, {0,1}, {1,0}, {0,-1}};
char yard[376][81], instruct[30001];

void check(int y, int x)
{
    for(int d=0; d<4; d++)
    {
        int step=1, tmpy=y, tmpx=x, tmpd=d, newy, newx;
        while(step<=m)
        {
            newy = tmpy+dir[tmpd][0]; newx = tmpx+dir[tmpd][1];
            if(instruct[step]=='F')
                if(newy>=1 && newy<=r && newx>=1 && newx<=c && yard[newy][newx]!='X'){
                   tmpy = newy; tmpx = newx;
                }
                else break;
            else if (instruct[step]=='R')
                tmpd = (tmpd+1)%4;
            else if (instruct[step]=='L')
                tmpd = (tmpd-1+4)%4;
            step++;
        }
        if(step>m) yard[tmpy][tmpx] = '*';
    }
}

int main()
{
    //freopen("blindfold.txt", "r", stdin);
    cin >> r >> c;
    for(int i=1; i<=r; i++)
        for(int j=1; j<=c; j++)
            cin >> yard[i][j];
    cin >> m;
    for(int i=1; i<=m; i++)
        cin >> instruct[i];
    for(int i=1; i<=r; i++)
        for(int j=1; j<=c; j++)
            if(yard[i][j]!='X')
                check(i, j);
    for(int i=1; i<=r; cout<<endl, i++)
        for(int j=1; j<=c; j++)
            cout << yard[i][j];

    return 0;
}