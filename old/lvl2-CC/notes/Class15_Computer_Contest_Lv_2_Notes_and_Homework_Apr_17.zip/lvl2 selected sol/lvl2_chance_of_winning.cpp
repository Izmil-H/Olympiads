#include <iostream>
#include <stdio.h>
#include <cstring>
#include <vector>
using namespace std;

int times = 0;

void recursion(int match[4][4], int score[4], int match_left, int t){
    vector<int>x(5);
    vector<int>y(5);
    if (match_left==0){
        int maxi = score[t-1];
        for(int counter = 0; counter<4; counter++)
            if(score[counter]>=maxi && counter!=t-1)
                maxi = -1;
        if(maxi != -1)
            times++;
    }
    else{
        for(int i = 0; i<4; i++)
            for(int j = 0; j<4; j++)
                if(match[i][j] == -1 && i!=j){
                    match[i][j] = match[j][i] = 1;
                    x.push_back(i);
                    y.push_back(j);
                    x.push_back(j);
                    y.push_back(i);
                    score[i]+=3;
                    recursion(match, score, match_left-1, t);
                    score[i]-=3;
                    score[i]+=1;
                    score[j]+=1;
                    recursion(match, score, match_left-1, t);
                    score[i]-=1;
                    score[j]-=1;
                    score[j]+=3;
                    recursion(match, score, match_left-1, t);
                    score[j]-=3;
                }
        for(int i=0;i<x.size();i++)
            match[x[i]][y[i]]=-1;
    }
}

int main()
{
    //freopen("test.txt", "r", stdin);
    int t, g, sa, sb, a, b, score[4], match_left=6, match[4][4];
    memset(match, -1, sizeof(match));
    memset(score, 0, sizeof(score));
    cin >> t >> g;
    for(int i = 0; i<g; i++){
        cin >> a >> b >> sa >> sb;
        if(sa>sb)
            score[a-1]+=3;
        else if(sa<sb)
            score[b-1]+=3;
        else if(sa == sb){
            score[b-1]+=1;
            score[a-1]+=1;
        }
        match_left--;
        match[a-1][b-1] = 1;
        match[b-1][a-1] = 1;
    }
    recursion(match, score, match_left, t);
    cout << times;
    return 0;
}