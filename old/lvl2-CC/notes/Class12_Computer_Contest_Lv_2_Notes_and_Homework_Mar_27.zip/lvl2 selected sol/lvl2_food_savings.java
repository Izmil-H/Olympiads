import java.util.*;
import java.io.*;
public class homework {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static PrintWriter pr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException{
		int n = readInt(), q = readInt(), psa[] = new int[n+1];
		for(int i=1; i<=n; i++) {
			psa[i] = psa[i-1] + readInt();
		}
		for(int i=1; i<=q; i++) {
			int x1 = readInt(), y1 = readInt(), x2 = readInt(), y2 = readInt();
			int sum1 = psa[y1] - psa[x1-1], sum2 = psa[y2] - psa[x2-1];
			double ans1 = Math.min(sum1, 10) + 0.5 * sum2, ans2 = Math.min(sum2, 10) + 0.5 * sum1;
			if(ans1 > ans2)
				pr.printf("%.1f\n", ans1);
			else 
				pr.printf("%.1f\n", ans2);
		}
		pr.close();
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}