#include <bits/stdc++.h>
using namespace std;
#define f first
#define s second
#define lc (rt<<1)
#define rc (rt<<1|1)
#define pb push_back
#define cl(a, b) memset(a, b, sizeof(a))
#define mp(a, b) make_pair((a), (b))
#define all(x) x.begin(),x.end()
typedef long long ll;
typedef pair<int, int> pi;
typedef pair<ll, ll> pl;
typedef pair<pi, int> pii;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<pi> vii;
typedef vector<pl> vll;
typedef vector<pii> viii;
const int inf = 0x3F3F3F3F;
const ll infl = 0x3F3F3F3F3F3F3F3FLL;
const int mod = 1e9 + 7, MM = 1e4+2;
int n, ans = -1, x[MM], y[MM], w[MM], h[MM], p, q;
int main(){
    //freopen("test.txt", "r", stdin);
    ios::sync_with_stdio(0), cin.tie(0), cout.tie(0);
    cin >> n;
    for(int i=1; i<=n; i++) cin >> x[i] >> y[i] >> w[i] >> h[i];
    cin >> p >> q;
    for(int i=1; i<=n; i++) {
        if(x[i] <= p && x[i] + w[i] >= p && y[i] <= q && q <= y[i] + h[i]){
            ans = i;
        }
    }
    cout << ans << endl;
}