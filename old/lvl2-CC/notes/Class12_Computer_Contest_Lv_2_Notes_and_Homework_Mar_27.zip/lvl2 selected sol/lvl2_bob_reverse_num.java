import java.util.*;
public class test2{
	public static void main(String [] args){
	    Scanner in = new Scanner(System.in);
	    StringBuilder a = new StringBuilder(in.next()), b = new StringBuilder(in.next());
	    System.out.println(Math.min(Long.parseLong(a.reverse().toString()), Long.parseLong(b.reverse().toString())));
	}
}