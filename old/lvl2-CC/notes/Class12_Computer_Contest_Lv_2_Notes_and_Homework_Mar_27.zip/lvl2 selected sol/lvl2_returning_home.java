import java.util.*;
import java.io.*;
public class homework {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException{
		int n = readInt(), m = readInt(), len = readInt(), ans = 0;
		boolean q [][] = new boolean[len][len];
		List<String> lst = new ArrayList();
		for(int i=0; i<n; i++) lst.add(readLine());
		for(int i=0; i<m; i++) {
			q[readInt() - 1][readInt() - 1] = true;
		}
		for(String x: lst) {
			boolean palindrome = true;
			for(int i=0; i<x.length() && palindrome; i++) {
				for(int j=i; j<x.length() && palindrome; j++) {
					if(!q[i][j]) continue;
					for(int pl=i, pr=j; pl<pr && palindrome; pl++, pr--)
						if(x.charAt(pl) != x.charAt(pr)) palindrome = false;
				}
			}
			if(palindrome) ans++;
		}
		System.out.println(ans);
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}