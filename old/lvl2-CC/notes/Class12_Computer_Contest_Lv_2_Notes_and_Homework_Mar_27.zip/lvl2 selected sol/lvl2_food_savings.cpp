#include <bits/stdc++.h>
using namespace std;
const int MM = 1e5+2;
int N, Q, psa[MM];
int main(){
    cin >> N >> Q;
    for(int i=1; i<=N; i++){
        cin >> psa[i];
        psa[i] += psa[i-1];
    }
    for(int i=1, a1, b1, a2, b2; i<=Q; i++){
        cin >> a1 >> b1 >> a2 >> b2;
        int s1 = psa[b1] - psa[a1-1], s2 = psa[b2] - psa[a2-1];
        double ans1 = min(s1, 10) + 0.5*s2,  ans2 = min(s2, 10) + 0.5*s1;
        cout << fixed << setprecision(1) << max(ans1, ans2) << "\n";
    }
}