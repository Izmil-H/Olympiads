#include <bits/stdc++.h>
using namespace std;
int N, M, len, ans; bool q[30][30];
int main(){
    ios::sync_with_stdio(0); cin.tie(0);
    cin >> N >> M >> len;  vector<string> s(N);
    for(int i=0; i<N; i++)
        cin >> s[i];
    for(int i=0, x, y; i<M; i++){
        cin >> x >> y;  q[x-1][y-1] = true;
    }
    for(string x: s){
        bool palin = true;
        for(int i=0; i<x.size() && palin; i++){
            for(int j=i; j<x.size() && palin; j++){
                if(!q[i][j]) continue;
                for(int pl=i, pr=j; pl<pr && palin; pl++, pr--)
                    if(x[pl] != x[pr]) palin = false;
            }
        }
        if(palin) ans++;
    }
    cout << ans << endl;
}