import java.util.*;
import java.io.*;
public class homework {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException{
		int n = readInt(), coin[] = new int[n+2], pre[] = new int[n+2], suf[] = new int[n+2], ans = 0;
		for(int i=1; i<=n; i++) {
			coin[i] = readInt();
		}
		pre[1] = 1; suf[n] = 1;
		for(int i=2; i<=n; i++) {
			if(coin[i] != coin[i-1]) pre[i] = pre[i-1] + 1;
			else pre[i] = 1;
			ans = Math.max(ans, pre[i]);
		}
		for(int i=n-1; i>=1; i--) {
			if(coin[i] != coin[i+1]) suf[i] = suf[i+1] + 1;
			else suf[i] = 1;
		}
		for(int i=1; i<n; i++) {
			if(coin[i] == coin[i+1])
				ans = Math.max(ans, pre[i-pre[i]] + pre[i] + suf[i+1]);
		}
		System.out.println(ans);
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}