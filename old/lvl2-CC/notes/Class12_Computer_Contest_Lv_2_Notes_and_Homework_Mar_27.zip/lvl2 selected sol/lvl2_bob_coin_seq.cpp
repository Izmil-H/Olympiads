#include <bits/stdc++.h>
using namespace std;
int n;
int main(){
    cin >> n;
    int coin[n+2]={};
    int pre[n+2]={};
    int suf[n+2]={};
    int ans = 0;
    for(int i = 1; i <=n; i++){
        cin >> coin[i];
    }
    pre[1] = 1; suf[n] = 1;
    for(int i = 2; i <= n; i++){
        if(coin[i] != coin[i-1]) pre[i] = pre[i-1] + 1;
        else pre[i] = 1;
        ans = max(ans, pre[i]);
    }
    for(int i=n-1; i >=1; i--){
        if(coin[i] != coin[i+1]) suf[i] = suf[i+1] + 1;
        else suf[i] = 1;
    }
    /*for(int x:suf){
        cout << x << ' ';
    }
    cout << endl;
    for(int x:pre){
        cout << x << ' ';
    }
    cout << endl;
    **/
    for(int i=1; i < n; i++){
        if(coin[i] == coin[i+1]){
            ans = max(ans, pre[i-pre[i]] + pre[i] + suf[i+1]);
        }
    }
    cout << ans;
    return 0;
}