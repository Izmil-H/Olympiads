import sys
input = sys.stdin.readline
n, d, k = map(int, input().split())
a = list(map(int, input().split()))
a.sort()
ans = 0
for i in range(n-k):
    ans += (a[i] + d - 1)//d
print(ans)