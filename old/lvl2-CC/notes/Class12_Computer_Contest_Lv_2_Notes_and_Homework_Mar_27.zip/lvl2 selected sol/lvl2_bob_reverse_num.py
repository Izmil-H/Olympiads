import sys
input = sys.stdin.readline
a, b = input().split()
print(min(int(a[::-1]), int(b[::-1])))