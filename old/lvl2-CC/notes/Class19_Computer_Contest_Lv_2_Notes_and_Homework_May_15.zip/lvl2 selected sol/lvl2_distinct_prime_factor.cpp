#include <bits/stdc++.h>
using namespace std;
const int maxN=1000002;
int A,B,cnt[maxN];
int main(){
    scanf("%d %d", &A, &B);
    for(int i=2; i<=B; i++)
        if(!cnt[i]){
            for(int j=i; j<=B; j+=i)
                cnt[j]++;
        }
    for(int i=A; i<=B; i++)
        printf("%d\n", cnt[i]);
}