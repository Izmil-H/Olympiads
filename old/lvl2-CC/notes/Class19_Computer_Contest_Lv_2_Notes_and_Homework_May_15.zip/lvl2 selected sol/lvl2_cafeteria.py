import sys
import bisect
input = sys.stdin.readline

n, q = map(int, input().split())
m = [0] + list(map(int, input().split()))
v = [0] + list(map(int, input().split()))
for i in range(1, n+1):
    m[i] += m[v[i]]
for i in range(1, n+1):
    m[i] = max(m[i], m[i-1])
for i in range(q):
    p, c = map(int, input().split())
    c -= p
    if c <= 0:
        print(-1)
    else:
        pos = bisect.bisect_left(m, c)
        print(pos) if pos <= n else print(-1)