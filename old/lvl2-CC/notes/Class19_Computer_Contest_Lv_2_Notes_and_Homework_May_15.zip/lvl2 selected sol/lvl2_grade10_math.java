import java.util.*;
import java.io.*;
public class homework {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static PrintWriter pr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException{
		int a = readInt(), b = readInt(); Map<Integer, Integer> fact = new HashMap();
		for(int i = 2, limit = (int)Math.sqrt(a); i <= limit; i++) {
			int cnt = 0;
			while(a % i == 0) {
				a /= i; cnt++;
			}
			if(cnt > 0) fact.put(i, cnt);
		}
		if(a != 1) fact.put(a, 1);
		int ans = Integer.MAX_VALUE;
		for(int f : fact.keySet()) {
			int cnt = fact.get(f), tot = 0; long cur = f;
			while(b >= cur) {
				tot += b / cur; cur *= f;
			}
			ans = Math.min(ans, tot/cnt);
		}
		System.out.println(ans);
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}