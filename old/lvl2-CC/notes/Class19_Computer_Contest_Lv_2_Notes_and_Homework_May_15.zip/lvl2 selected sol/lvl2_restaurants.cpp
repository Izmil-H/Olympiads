#include <bits/stdc++.h>
using namespace std;
const int MM = 1000001;
int N, T, K, V, cnt, ans; bool res[MM]; vector<int> st;
int main(){
    scanf("%d %d %d %d", &N, &T, &K, &V);
    for(int i=1, x; i<=V; i++){
        scanf("%d", &x); res[x]=1;
    }
    for(int i=1; i<=N; i++){
        cnt += res[i];
        if(!res[i]) st.push_back(i);
        if(i >= T) {
            cnt -= res[i-T];
            while(cnt < K){
                int x = st.back(); st.pop_back();
                res[x] = 1; cnt++; ans++;
            }
        }
    }
    printf("%d\n", ans);
}