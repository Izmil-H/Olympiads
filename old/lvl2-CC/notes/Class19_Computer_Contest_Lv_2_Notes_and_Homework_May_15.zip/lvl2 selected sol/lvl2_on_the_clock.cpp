#include <bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define LINF 0x3f3f3f3f3f3f3f3f
#define pb push_back
#define endl "\n"
#define TRACE(x) cerr << #x << " = " << x << endl
#define set(arr, x) memset(arr, x, sizeof(arr))
#define copy(start, dest) memcpy(dest, start, sizeof(start));
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int, int> pii;

const int maxN = 101, mod = 1e9+7;
inline ll gcd(ll a, ll b) {return b == 0 ? a:gcd(b, a%b);}

int32_t main(void) {
    cin.tie(0)->sync_with_stdio(0);
    int n, m; cin >> n >> m;
    cout << n+m-gcd(n, m) << endl;
    for(int i = 1; i <= n; i++){
        for(int j = 1LL*m*(i-1)/n + 1; j <= (1LL*m*i+n-1)/n; j++){
            cout << i << " " << j << endl;
        }
    }
}