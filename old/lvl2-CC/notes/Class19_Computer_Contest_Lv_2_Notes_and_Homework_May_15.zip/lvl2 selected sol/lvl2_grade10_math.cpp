#include <bits/stdc++.h>
using namespace std;
typedef pair<int, int> pi;
int a, b, ans = 1e9; vector<pi> fact;
int main(){
    cin >> a >> b;
    for(int i=2; i<=sqrt(a); i++){
        int cnt = 0;
        while(a % i == 0){
            cnt++; a/=i;
        }
        if(cnt) fact.push_back({i, cnt});
    }
    if(a != 1) fact.push_back({a, 1});
    for(pi e: fact){
        int x = e.first, cnt = e.second, tot = 0, cur = x;
        while(b >= cur){
            tot += b/cur;  cur*=x;
        }
        ans = min(ans, tot/cnt);
    }
    cout << ans << "\n";
}