#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MM = 1e5+2;
int N, Q; ll m[MM], p, c;
int main(){
    ios::sync_with_stdio(0); cin.tie(0);
    cin >> N >> Q;
    for(int i=1; i<=N; i++) cin >> m[i];
    for(int i=1, x; i<=N; i++) {
        cin >> x; m[i] += m[x];
    }
    for(int i=1; i<=N; i++) {
        m[i] = max(m[i], m[i-1]);
    }
    for(int i=1; i<=Q; i++) {
        cin >> p >> c;   c -= p;
        if(c <= 0) {
            cout << -1 << "\n";
        }else {
            int pos = lower_bound(m, m+N+1, c) - m;
            cout << (pos <= N ?   pos : -1 ) << "\n";
        }
    }
}