import java.util.*;
import java.io.*;
public class homework {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException{
		long n = readLong();
		List<Long> list = new ArrayList();
		list.add(0L);  int p = 0;
		while(true) {
			long num = list.get(p)*10 + 2;
			if(num > n) break;
			list.add(num);
			num = list.get(p)*10 + 3;
			if(num > n) break;
			list.add(num);
			p++;
		}
		System.out.println(list.size() - 1);
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}