#include <bits/stdc++.h>
using namespace std;
typedef pair<int, int> pi;
set<pi> pt; int N, ans, x[2000], y[2000];
int main(){
    cin >> N;
    for(int i=0; i<N; i++){
        cin >> x[i] >> y[i];
        pt.insert({x[i], y[i]});
    }
    for(int i=0; i<N; i++){
        for(int j=i+1; j<N; j++){
            if(pt.count({x[i], y[j]}) && pt.count({x[j], y[i]})){
                ans = max(ans, abs(x[i]-x[j]) * abs(y[i]-y[j]));
            }
        }
    }
    cout << ans << "\n";
}