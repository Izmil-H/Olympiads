#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll N;
ll fun(ll cur){
    if(cur > N) return 0;
    return fun(cur*10 + 2) + fun(cur*10 + 3) + 1;
}
int main(){
    cin >> N;
    cout << fun(2) + fun(3) << endl;
}