#include <bits/stdc++.h>
using namespace std;
int main(){
    int n;
    cin >> n;
    int w[n];
    for(int i=0; i<n; i++){
        cin >> w[i];
    }
    sort(w, w+n);
    int sum = 0, cnt = 0;
    for(int i=0; i<n; i++){
        if(sum <= w[i]){
            sum += w[i]; cnt++;
        }
    }
    cout << cnt << endl;
}