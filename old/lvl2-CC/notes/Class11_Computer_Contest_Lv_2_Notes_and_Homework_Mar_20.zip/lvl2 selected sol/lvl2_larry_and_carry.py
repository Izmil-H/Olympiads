import sys
from itertools import combinations
input = sys.stdin.readline

def carry(x, y):
    while x > 0 and y > 0:
        if x % 10 + y % 10 >= 10:
            return True
        x //= 10
        y //= 10
    return False

def check(lst):
    if len(lst) == 1:
        return True
    tot = 0
    for x in lst:
        if carry(tot, x):
            return False
        tot += x
    return True

n = int(input())
a = []
ans = 0
for i in range(n):
    a.append(int(input()))

for k in range(1, n+1):
    for lst in combinations(a, k):
        if check(lst):
            ans = max(ans, k)
print(ans)