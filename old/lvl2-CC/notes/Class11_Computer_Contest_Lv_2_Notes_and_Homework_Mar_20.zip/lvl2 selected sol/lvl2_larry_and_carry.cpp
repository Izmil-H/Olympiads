#include <bits/stdc++.h>
using namespace std;
vector<int> a, comb;     int n, ans;
bool noCarry(int x, int y){
    while(x > 0 && y > 0){
        if(x % 10 + y % 10 >= 10) return false;
        x/=10; y/=10;
    }
    return true;
}
void fun(int id, vector<int>& a, vector<int>& comb){
    if(id == a.size()){
        int sum = 0;
        for(int x: comb) {
            if(noCarry(sum, x))  sum+=x;
            else return;
        }
        ans = max(ans, (int)comb.size()); return;
    }
    fun(id+1, a, comb);
    comb.push_back(a[id]);
    fun(id+1, a, comb);
    comb.pop_back();
}
int main(){
    cin >> n;   a.resize(n);
    for(int i=0; i<n; i++) cin >> a[i];
    fun(0, a, comb);
    cout << ans << endl;
}