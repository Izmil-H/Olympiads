n = int(input())
x = {}
for i in range(n):
    a = int(input())
    if a in x: x[a] += 1
    else: x[a] = 1
y = sorted(x.items(),key=lambda i:i[1],reverse=True)
if len(y)==1: print(n)
else: print(y[0][1]+y[1][1])