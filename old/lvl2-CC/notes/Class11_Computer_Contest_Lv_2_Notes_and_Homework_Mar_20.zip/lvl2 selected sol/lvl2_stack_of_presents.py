import sys

n = int(sys.stdin.readline())
a = []
for _ in range(n):
    a.append(int(sys.stdin.readline()))
a.sort()

def main():
    sum = a[0]
    count = 1
    for i in range(1, len(a)):
        if a[i] >= sum:
            sum += a[i]
            count += 1
    print(count)


main()