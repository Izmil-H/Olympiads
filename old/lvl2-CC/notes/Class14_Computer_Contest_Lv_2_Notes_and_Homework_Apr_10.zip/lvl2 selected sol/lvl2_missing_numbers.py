import sys
import math
input = sys.stdin.readline

t = int(input())
for i in range(t):
    n, s = map(int, input().split())
    total = n * (n + 1) // 2
    diff = total - s
    maxB = min(n, diff-1)
    minB = diff //2
    print(maxB - minB)