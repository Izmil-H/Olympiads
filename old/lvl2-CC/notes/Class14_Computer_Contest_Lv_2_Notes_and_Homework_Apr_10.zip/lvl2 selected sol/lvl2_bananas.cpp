#include <bits/stdc++.h>
using namespace std;
string s;
int main(){
    while(true) {
        cin >> s;
        if(s == "X") break;
        while(true){
            int p1 = s.find("ANA"), p2 = s.find("BAS");
            if(p1 == -1 && p2 == -1) break;
            if(p1 != -1) s.replace(p1, 3, "A");
            p2 = s.find("BAS");
            if(p2 != -1) s.replace(p2, 3, "A");
        }
        cout << (s == "A"? "YES" : "NO") << "\n";
    }
}