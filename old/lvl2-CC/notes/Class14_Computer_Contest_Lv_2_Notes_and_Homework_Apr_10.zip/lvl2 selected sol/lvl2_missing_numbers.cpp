#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int t; ll n, s;
int main(){
    for(cin >> t; t>0; t--){
        cin >> n >> s;
        ll dif = n*(1+n)/2 - s;
        cout << min(n, dif-1) - dif/2 << "\n";
    }
}