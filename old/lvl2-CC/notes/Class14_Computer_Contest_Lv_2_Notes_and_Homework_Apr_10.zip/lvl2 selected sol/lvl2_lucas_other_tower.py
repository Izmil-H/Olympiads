for _ in range(10):
    n, t = map(int, input().split())
    print(2*n - 1)