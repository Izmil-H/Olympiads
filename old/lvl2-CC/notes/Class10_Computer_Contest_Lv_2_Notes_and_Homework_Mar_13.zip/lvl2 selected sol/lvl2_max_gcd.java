import java.util.*;
import java.io.*;
public class Test {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException {
		int n = readInt(), a[] = new int[n+2], pre[] = new int[n+2], suf[] = new int[n+2];
		for(int i=1; i<=n; i++) {
			a[i] = readInt(); 
			pre[i] = GCD(pre[i-1], a[i]);
		}
		for(int i=n; i>=1; i--) {
			suf[i] = GCD(suf[i+1], a[i]);
		}
		int ans = 0;
		for(int i=1; i<=n; i++)
			ans = Math.max(ans, GCD(pre[i-1], suf[i+1]));
		System.out.println(ans);
	}
	static int GCD(int x, int y) {
		return y==0? x: GCD(y, x%y);
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}