import math

x = int(input())
a = list(str(x))
a.sort()
ind = x + 1

while True:
    b = list(str(ind))
    if len(b) > len(a):
        print(0)
        break
    b.sort()
    if a == b:
        print(ind)
        break
    ind += 1