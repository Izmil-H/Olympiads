#include <bits/stdc++.h>
using namespace std;
string s;
int main(){
    cin >> s;
    bool flag = next_permutation(s.begin(), s.end());
    if(!flag) cout << 0 << "\n";
    else cout << s << "\n";
}