import java.util.*;
public class ccchk08j3_phone_book {
	public static void main(String [] args){
		Scanner in = new Scanner(System.in);
		int N = in.nextInt();
		String name[] = new String[N], phone[] = new String[N];
		HashMap<String, Integer> mp = new HashMap<String, Integer>();
		for(int i=0; i<N; i++){
			name[i] = in.next(); phone[i] = in.next();
		}
		int D = in.nextInt();
		for(int i=0; i<D; i++){
			String s = in.next(); mp.put(s, mp.getOrDefault(s, 0)+1);
		}
		int max = 0; String freqName = "", freqPhone = "";
		for(int i=0; i<N; i++){
			int t = mp.getOrDefault(phone[i], 0);
			if(t > max || t==max && phone[i].compareTo(freqPhone) < 0 ){
				max = mp.get(phone[i]); freqName = name[i]; freqPhone = phone[i];
			}
		}
		System.out.println(freqName);
	}
}