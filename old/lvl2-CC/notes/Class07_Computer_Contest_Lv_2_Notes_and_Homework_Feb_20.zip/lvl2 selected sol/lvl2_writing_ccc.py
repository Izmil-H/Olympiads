import sys
input = sys.stdin.readline
mp = {}
t = []
for i in range(int(input())):
    type = input().strip()
    mp[type] = []
    t.append(type)
for i in range(int(input())):
    type = input().strip()
    mp[type].append(i+1)
for p in t:
    for x in mp[p]:
        print(x)