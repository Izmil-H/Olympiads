#include <bits/stdc++.h>
using namespace std;
int n, k, ans;
int main(){
    cin >> n >> k; vector<int> a(n);
    for(int i=0; i<n; i++)
        cin >> a[i];
    sort(a.begin(), a.end());
    for(int L=0, R=0; R<n; R++) {
        while(a[R]-a[L] > k) {
            L++;
        }
        ans = max(ans, R-L+1);
    }
    cout << ans << endl;
}