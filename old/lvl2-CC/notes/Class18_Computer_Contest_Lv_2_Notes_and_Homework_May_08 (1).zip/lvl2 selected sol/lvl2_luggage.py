import sys
input = sys.stdin.readline
n, k = map(int, input().split())
h = list(map(int, input().split()))
h.sort()
l, ans = 0, 0
for r in range(n):
    while h[r] - h[l] > k:
        l+=1
    ans = max(ans, r - l + 1)
print(ans)