#include <bits/stdc++.h>
using namespace std;
const int MM = 1e5+5;
int T, K, A, B, f[MM]; vector<int> p[MM];
int main(){
    for(int i=1; i<MM; i++){
        for(int j=i; j<MM; j+=i) f[j]++;
        p[f[i]].push_back(i);
    }
    for(cin >> T;  T; T--) {
        cin >> K >> A >> B;
        cout << upper_bound(p[K].begin(), p[K].end(), B) - lower_bound(p[K].begin(), p[K].end(), A) <<"\n";
    }
}