import sys
import bisect
input = sys.stdin.readline
T = int(input())
cnt = [1]*100001
lst = [[] for i in range(100000)]
lst[1].append(1)
for i in range(2, 100001):
    for j in range(i, 100001, i):
        cnt[j]+=1
    lst[cnt[i]].append(i)
for t in range(T):
    k, a, b = map(int, input().split())
    print(bisect.bisect_left(lst[k], b+1) - bisect.bisect_left(lst[k], a))