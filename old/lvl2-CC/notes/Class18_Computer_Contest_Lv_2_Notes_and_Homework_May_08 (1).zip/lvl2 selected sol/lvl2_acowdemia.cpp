#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<float, float> pff;
#define f first
#define s second

int main(){
    int N, K, L; cin >> N >> K >> L;
    int citation[N];
    for(int i = 0; i< N; i++){
        cin >> citation[i];
    }
    sort(citation, citation+N, greater<int>());
    int lo = 0, hi = N, mid;
    int ans = 0;
    while(lo <= hi){
        mid = (hi+lo)/2;
        ll amount = 0;
        bool check = true;
        for(int i = 0; i< mid; i++){
            if(mid > citation[i]+K){
                check = false;
                break;
            }
            if(citation[i] < mid){
                amount += mid-citation[i];
            }
            if(amount > 1LL*K*L){
                check = false;
                break;
            }
        }
        if(check){
            ans = mid;
            lo = mid+1;
        }else{
            hi = mid-1;
        }
    }
    cout << ans << endl;
}