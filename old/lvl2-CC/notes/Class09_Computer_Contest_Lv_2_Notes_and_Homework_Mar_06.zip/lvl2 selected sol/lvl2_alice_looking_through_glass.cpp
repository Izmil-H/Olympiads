#include <bits/stdc++.h>
#include <math.h>
using namespace std;
bool f(int x0, int y0, int m)
{
    int sz = (int)pow(5, m-1), x = x0/sz, y = y0/sz;
	if (x == 1 && y == 0 || x == 2 && y == 0 || x == 2 && y == 1 || x == 3 && y == 0)
	    return true;
	if (m > 1 && ( x== 1&&y == 1|| x == 2 && y == 2 || x == 3 && y == 2))
	    return f(x0 % sz, y0 % sz, m - 1);
	return false;
}
int main()
{
	int T, x, y, m;
	scanf("%d", &T);
	for (int i = 0; i < T; i++)
	{
		scanf("%d%d%d", &m, &x, &y);
		if (f(x, y, m))
		    printf("crystal\n");
		else
		    printf("empty\n");
	}
}