#include <bits/stdc++.h>
using namespace std;

string a, b;

int fastpow (int base, int exp, int mod){
    if (exp==0) return 1;
    int t = fastpow(base, exp/2, mod);
    t=t*t%mod;
    if (exp%2==0) return t;
    return t*base%mod;
}
int main() {
    cin >> a >> b;
    int acount=0, bcount=0;
    for (int i=0; i<a.length(); i++){
        acount+=fastpow(tolower(a[i])-'a'+1, i+1, 10);
    }
    for (int i=0; i<b.length(); i++){
        bcount+=fastpow(tolower(b[i])-'a'+1, i+1, 10);
    }
    acount%=10;
    bcount%=10;
    if (acount==0) acount=10;
    if (bcount==0) bcount=10;
    cout << acount+bcount << '\n';

    return 0;
}