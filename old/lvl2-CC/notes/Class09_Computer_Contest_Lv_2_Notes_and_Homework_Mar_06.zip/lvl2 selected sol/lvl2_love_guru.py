def fastpow(x, n, mod):
    ans = 1
    while n > 0:
        if n % 2 :
            ans = ans*x
        x = x*x % mod
        n //= 2
    return ans % mod
s = input().lower()
t = input().lower()
ans1, ans2 = 0, 0

for i in range(len(s)):
    ans1 += fastpow(ord(s[i]) - 96, i+1, 10)

for i in range(len(t)):
    ans2 += fastpow(ord(t[i]) - 96, i+1, 10)

ans1, ans2 = ans1%10, ans2%10
if ans1 == 0:
    ans1 += 10
if ans2 == 0:
    ans2 += 10
print(ans1 + ans2)