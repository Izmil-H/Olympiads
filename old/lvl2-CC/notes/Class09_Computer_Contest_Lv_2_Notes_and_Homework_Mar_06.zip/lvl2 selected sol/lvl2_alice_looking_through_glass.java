import java.util.*;
import java.io.*;
public class homework {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	static int a[][] = new int[5][5];
	public static void main(String[] args) throws IOException{
		a[1][0] = a[2][0] = a[3][0] = a[2][1] = 1;  //always crystal
		a[1][1] = a[2][2] = a[3][1] = -1; //not sure 
		for(int T = readInt(); T > 0; T--) {
			int m = readInt(), x = readInt(), y = readInt();
			System.out.println(fun(m, x, y)? "crystal": "empty");
		}
	}
	static boolean fun(int m, int x, int y) {
		int sz = (int)Math.pow(5, m-1), bx = x/sz, by = y/sz;
		if( a[bx][by] == 1 ) {
			return true;
		}else if(a[bx][by] == -1) {
			if(m == 1) return false;
			return fun(m-1, x % sz, y % sz);
		}else {
			return false;
		}
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}