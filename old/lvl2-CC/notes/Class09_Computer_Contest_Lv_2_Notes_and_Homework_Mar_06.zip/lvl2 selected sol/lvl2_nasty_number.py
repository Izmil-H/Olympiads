n = int(input())
for _ in range(n):
    a = int(input())
    l = []
    good = False
    for y in range(1, int(a**(1/2))+1):
        if a % y == 0:
            l.append((y, a//y))
    for x1, y1 in l:
        for x2, y2 in l:
            if abs(x2-y2) == x1+y1 or  abs(x1-y1) == x2+y2:
                good = True
                break
    if good:
        print(a, "is nasty")
    else:
        print(a, "is not nasty")
        