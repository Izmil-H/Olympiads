import java.util.*;
public class test2{
	public static void main(String [] args){
	    Scanner in = new Scanner(System.in);
	    int R = in.nextInt(), C = in.nextInt(), a[][] = new int[R][C];
	    Integer row[] = new Integer[R];
	    for(int i=0; i<R; i++) {
	    	row[i] = i;
	    	for(int j=0; j<C; j++) {
	    		a[i][j] = in.nextInt();
	    	}
	    }
	    int n = in.nextInt();
	    for(int i=1; i<=n; i++) {
	    	int col = in.nextInt() - 1;
	    	Arrays.sort(row, new Comparator<Integer>() {
	    		public int compare(Integer x, Integer y) {
	    			return Integer.compare(a[x][col], a[y][col]);
	    		}
	    	});
	    }
	    for(int i=0; i<R; i++) {
	    	for(int j=0; j<C; j++)
	    		System.out.print(a[row[i]][j] + " ");
	    	System.out.println();
	    }
	}
}