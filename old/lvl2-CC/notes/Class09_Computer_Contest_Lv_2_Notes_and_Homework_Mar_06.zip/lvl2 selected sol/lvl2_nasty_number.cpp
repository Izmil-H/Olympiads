#include <iostream>
#include <set>
#include <cmath>
#include <algorithm>
using namespace std;

int main()
{
    int t, n, fac, upp;
    cin >> t;
    while(t--){
        bool flag=false;
        set<int> diff;
        cin >> n;
        upp = (int)sqrt(n);
        for(int i=1; i<=upp; i++)
            if(n%i==0){
                fac = n/i;
                if(diff.find(i+fac)!=diff.end()){
                    flag = true; break;
                }
                diff.insert(abs(i-fac));
            }
        if(flag) cout << n << " is nasty" << endl;
        else cout << n << " is not nasty" << endl;
    }
}