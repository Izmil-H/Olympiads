import sys
import math
input = sys.stdin.readline

n = int(input())
a = list(map(int, input().split()))
st = set(a)
if n == 2:
    print(2) if (a[0] + a[1]) % 2 == 0 else print(1)
else:
    found = False
    for i in range(n):
        for j in range(i+1, n):
            avg = (a[i] + a[j])//2
            if 2*avg == a[i] + a[j] and avg in st:
                found = True
                break
        if found:
            break
    print(3) if found else print(2)