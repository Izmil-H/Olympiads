#include <bits/stdc++.h>
using namespace std;
int n, target, h[11], ans = 1e9;
void fun(int i, vector<int>& comb){
    if(i > n) {
        int sum = 0;
        for(int x : comb) sum += h[x];
        if(sum == target) ans = min(ans, (int)comb.size());
        return;
    }
    fun(i+1, comb);
    comb.push_back(i); fun(i+1, comb); comb.pop_back();
}
int main(){
    ios::sync_with_stdio(0); cin.tie(0);
    cin >> target >> n;  vector<int> comb;
    for(int i=1; i<=n; i++) cin >> h[i];
    fun(1, comb);
    cout << (ans == 1e9? 0 : ans) << endl;
}