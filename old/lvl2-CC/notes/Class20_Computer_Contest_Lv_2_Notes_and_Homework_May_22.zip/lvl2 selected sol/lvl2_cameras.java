import java.util.*;
import java.io.*;
import java.math.*;
public class homework {
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    static StringTokenizer st;
    public static void main(String[] args) throws IOException{
    	int n = readInt(), k = readInt(), r = readInt(), cam[] = new int[n+1];
    	for(int i=1; i<=k; i++) cam[readInt()] = 1;
    	Stack<Integer> nocam = new Stack();
    	int cnt = 0, ans = 0;
    	for(int i=1; i<=n; i++) {
    		cnt += cam[i];
    		if(cam[i] == 0) nocam.push(i);
    		if(i >= r) {
    			cnt -= cam[i-r];
        		while(cnt < 2) {
        			int pos = nocam.pop();
        			cam[pos] = 1; cnt++; ans++;
        		}
    		}
    	}
    	System.out.println(ans);
    }
    static String next () throws IOException {
        while (st == null || !st.hasMoreTokens())
            st = new StringTokenizer(br.readLine().trim());
        return st.nextToken();
    }
    static long readLong () throws IOException {
        return Long.parseLong(next());
    }
    static int readInt () throws IOException {
        return Integer.parseInt(next());
    }
    static double readDouble () throws IOException {
        return Double.parseDouble(next());
    }
    static char readCharacter () throws IOException {
        return next().charAt(0);
    }
    static String readLine () throws IOException {
        return br.readLine().trim();
    }
}