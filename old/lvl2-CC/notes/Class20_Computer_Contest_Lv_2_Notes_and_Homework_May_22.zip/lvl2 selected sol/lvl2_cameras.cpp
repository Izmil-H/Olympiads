#include <bits/stdc++.h>
using namespace std;
const int MM = 1e5 + 2;
int n, k, r, a[MM], sum, ans;
int main(){
    ios::sync_with_stdio(0); cin.tie(0);
    cin >> n >> k >> r;
    for(int i=1, x; i<=k; i++){
        cin >> x; a[x] = 1;
    }
    for(int i=1; i<=n; i++) {
        sum += a[i];
        if(i >= r) {
            sum -= a[i-r];
            while(sum < 2) {
                if(!a[i]) { a[i] = 1; sum++; ans++; }
                else if(!a[i-1]) { a[i-1] = 1; sum++; ans++;}
            }
        }
    }
    cout << ans << endl;
}