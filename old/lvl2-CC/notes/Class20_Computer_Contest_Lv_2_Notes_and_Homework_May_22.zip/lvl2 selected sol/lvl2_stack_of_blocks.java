import java.util.*;
import java.io.*;
public class Test {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static PrintWriter pr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
	static StringTokenizer st;
	static int target, n, h[], ans=Integer.MAX_VALUE;
    public static void main(String [] args) throws IOException{
    	target = readInt(); n = readInt();  h = new int[n];
    	for(int i=0; i<n; i++) h[i] = readInt();
    	fun(0, 0, 0);  
    	if(ans > n) System.out.println(0);
    	else System.out.println(ans);
    }
    static void fun(int idx, int height, int num) {
    	if(idx >= n || height >= target) {
    		if(height == target) ans = Math.min(ans, num);
    		return;
    	}
    	fun(idx+1, height + h[idx], num+1); 
    	fun(idx+1, height, num);
    }
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}