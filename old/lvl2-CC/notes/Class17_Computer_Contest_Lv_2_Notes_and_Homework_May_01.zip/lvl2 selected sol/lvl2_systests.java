import java.util.*;
import java.io.*;
public class homework {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException {
		int batch = readInt(), st[] = new int[batch], ed[] = new int[batch], pt[] = new int[batch];
		for(int i=0; i<batch; i++) {
			st[i] = readInt(); ed[i] = readInt(); pt[i] = readInt();
		}
		int cases = readInt(), fail[] = new int[cases];
		for(int i=0; i<cases; i++) {
			fail[i] = readInt();
		}
		Arrays.sort(fail);
		int ans = 0;
		for(int i=0; i<batch; i++) {
			int pos = Arrays.binarySearch(fail, st[i]); //if exists, return index; otherwise -insert_point-1 = pos
			if(pos < 0) pos = -pos - 1;
			if(pos >= fail.length || fail[pos] > ed[i]) ans += pt[i];
		}
		System.out.println(ans);
	}
	static String next() throws IOException {
		while (st == null || !st.hasMoreTokens()) 
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong() throws IOException {
		return Long.parseLong(next());
	}
	static int readInt() throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble() throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter() throws IOException {
		return next().charAt(0);
	}
	static String readLine() throws IOException {
		return br.readLine().trim();
	}
}