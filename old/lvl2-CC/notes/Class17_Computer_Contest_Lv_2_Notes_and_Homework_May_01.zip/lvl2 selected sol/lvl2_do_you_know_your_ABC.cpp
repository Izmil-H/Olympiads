#include <bits/stdc++.h>
using namespace std;
int T, N, x[7];
int main(){
    for(cin >> T; T--; ){
        cin >> N; vector<int> cand;
        for(int i=0; i<N; i++) {
            cin >> x[i]; cand.push_back(x[i]);
            for(int j=0; j<i; j++)
                cand.push_back(abs(x[i] - x[j]));
        }
        sort(cand.begin(), cand.end());
        cand.resize(unique(cand.begin(), cand.end()) - cand.begin());
        int ans = 0;
        for(int i=0; i<cand.size(); i++) {
            for(int j=i; j<cand.size(); j++){
                for(int k=j; k<cand.size(); k++) {
                    int a = cand[i], b = cand[j], c = cand[k];
                    vector<int> tmp = {a, b, c, a+b, a+c, b+c, a+b+c}; bool flag=true;
                    for(int l=0; l<N; l++){
                        if(find(tmp.begin(), tmp.end(), x[l])==tmp.end()) flag=false;
                    }
                    if(flag) { ans++;}
                }
            }
        }
        cout << ans << endl;
    }
}