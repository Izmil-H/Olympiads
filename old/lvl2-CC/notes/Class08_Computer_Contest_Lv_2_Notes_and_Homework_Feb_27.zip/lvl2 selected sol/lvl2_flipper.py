import sys

input = sys.stdin.readline
N = int(input())
grid = [list(map(int, input().split())) for i in range(N)]
cols = [0] * N
rows = [0] * N
res = []
M = 0
for i in range(N):
    if grid[0][i]:
        cols[i] += 1
        res.append(("C", i + 1))
        M += 1
for i in range(N):
    if grid[i][0] ^ cols[0]:
        rows[i] += 1
        res.append(("R", i + 1))
        M += 1
for i in range(N):
    for j in range(N):
        if grid[i][j] ^ (cols[j] + rows[i]) % 2:
            print(-1)
            sys.exit()
print(M)
for i in res:
    print(*i)