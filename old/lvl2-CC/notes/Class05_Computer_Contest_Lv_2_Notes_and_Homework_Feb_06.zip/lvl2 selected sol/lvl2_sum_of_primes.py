import sys
input = sys.stdin.readline

m = int(1e7+1)
prime = [True]*m

def sieve():
    prime[0] = prime[1] = False
    for i in range(2, m):
        if prime[i]:
            for j in range(i*i, m, i):
                prime[j] = False

sieve()
for t in range(5):
    n = int(input())
    if prime[n]:
        print(n, '=', n)
    elif n % 2 == 0:
        for p in range(n//2, 2, -1):
            if prime[p] and prime[n-p]:
                print(n, '=', p, '+', n-p)
                break
    else:
        for p in range(n//3, 2, -1):
            if not prime[p]:
                continue
            x, found = n - p, False
            for q in range(x//2, p-1, -1):
                if prime[q] and prime[x-q]:
                    print(n, '=', p, '+', q, '+', x-q)
                    found = True
                    break
            if found:
                break