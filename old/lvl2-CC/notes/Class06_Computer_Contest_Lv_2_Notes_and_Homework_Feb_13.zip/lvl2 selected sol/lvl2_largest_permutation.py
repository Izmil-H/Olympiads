import sys
import math
input = sys.stdin.readline

n, k = map(int, input().split())
a = list(map(int, input().split()))
p = [0]*n
for i in range(n):
    p[a[i]-1] = i
for i in range(n):
    if a[i] != n-i:
        nxt = p[n-i-1]
        p[a[i]-1], p[n-i-1] = p[n-i-1], p[a[i]-1]
        a[i], a[nxt] = a[nxt], a[i]
        k-=1
    if k == 0:
        break
for i in range(n):
    print(a[i], end=' ')