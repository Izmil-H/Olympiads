import java.util.*;
import java.io.*;
public class homework {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException{
		int n = readInt(), swap = readInt(), a[] = new int[n+1], pos[] = new int[n+1];
		for(int i=1; i<=n; i++) {
			a[i] = readInt(); 
			pos[a[i]] = i;
		}
		for(int i=1; i<=n && swap > 0; i++) {
			if(a[i] < n - i + 1) {
				int p = pos[n - i + 1];
				int tmp = pos[a[i]]; pos[a[i]] = pos[n-i+1]; pos[n-i+1] = tmp;
				tmp = a[i]; a[i] = a[p]; a[p] = tmp;
				swap--;
			}
		}
		for(int i=1; i<=n; i++)
			System.out.print(a[i] + " ");
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}