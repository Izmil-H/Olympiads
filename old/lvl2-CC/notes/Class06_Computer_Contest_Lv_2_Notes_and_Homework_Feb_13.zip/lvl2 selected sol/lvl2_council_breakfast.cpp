#include <iostream>
#include <math.h>
using namespace std;
int pink, green, red, orange, amt, total;
int mi = 1e9;
int main() {
    cin>>pink>>green>>red>>orange>>amt;
	for (int a=0;a<=amt/pink;a++) {
		for (int b=0;b<=amt/green;b++) {
			for(int c=0;c<=amt/red;c++) {
				for(int d=0;d<=amt/orange;d++) {
					if(a*pink + b*green + c*red + d*orange == amt) {
						cout<<"# of PINK is "<<a<<" # of GREEN is "<<b<<" # of RED is "<<c<<" # of ORANGE is "<<d<<endl;
						total++;
						mi = min(mi,a+b+c+d);
					}
				}
			}
		}
	}
	cout<<"Total combinations is "<<total<<".\n";
	cout<<"Minimum number of tickets to print is "<<mi<<".\n";
}