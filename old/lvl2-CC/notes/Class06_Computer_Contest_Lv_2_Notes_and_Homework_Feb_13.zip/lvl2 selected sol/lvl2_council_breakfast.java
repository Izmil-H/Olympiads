import java.util.*;
import java.io.*;
public class homework {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException{
		int p = readInt(), g = readInt(), r = readInt(), o = readInt(), amt = readInt();
		int tot = 0, min = (int)1e9;
		for(int a=0; a<=amt/p; a++) {
			for(int b=0; b<=amt/g; b++) {
				for(int c=0; c<=amt/r; c++) {
					for(int d=0; d<=amt/o; d++) {
						if(a*p + b*g + c*r + d*o == amt) {
							System.out.println("# of PINK is "+a+" # of GREEN is "+b+" # of RED is "+c+" # of ORANGE is "+d);
							tot++;
							min = Math.min(min, a+b+c+d);
						}
					}
				}
			}
		}
		System.out.println("Total combinations is "+tot+".");
		System.out.println("Minimum number of tickets to print is "+min+".");
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}