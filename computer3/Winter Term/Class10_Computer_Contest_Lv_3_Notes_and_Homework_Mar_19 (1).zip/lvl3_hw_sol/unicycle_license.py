import sys
import math
input = sys.stdin.readline
m = int(input())
print((5 + math.sqrt(25 - 48*(1-m)))/24.0)