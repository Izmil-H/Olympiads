h, s = int(input()), int(input())
for _ in range(int(input())):
    h -= s
    print(h)