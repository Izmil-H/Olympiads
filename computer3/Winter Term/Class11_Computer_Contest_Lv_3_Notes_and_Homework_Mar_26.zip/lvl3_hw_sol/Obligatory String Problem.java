import java.util.*;
import java.io.*;
public class Main {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static PrintWriter pr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException {
		int k = readInt(); char s[] = readLine().toCharArray();
		for(char a ='a'; a<='z'; a++) {
			for(char b='a'; b<='z'; b++) {
				for(char c='a'; c<='z'; c++) {
					for(char d='a'; d<='z'; d++) {
						if(dis(a, s[0]) + dis(b, s[1]) + dis(c, s[2]) + dis(d, s[3]) <= k) {
							System.out.println(new char[] {a, b, c, d});
						}
					}
				}
			}
		}
	}
	static int dis(char a, char b) {
		return Math.min(Math.abs(a-b), 26 - Math.abs(a-b));
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}