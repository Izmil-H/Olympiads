#include <bits/stdc++.h>
using namespace std;
#define f first
#define s second
#define lc (rt<<1)
#define rc (rt<<1|1)
#define pb push_back
#define cl(a, b) memset(a, b, sizeof(a))
#define mp(a, b) make_pair((a), (b))
#define all(x) x.begin(),x.end()
typedef long long ll;
typedef pair<int, int> pi;
typedef pair<ll, ll> pl;
typedef pair<pi, int> pii;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<pi> vii;
typedef vector<pl> vll;
typedef vector<pii> viii;
const int inf = 0x3F3F3F3F;
const ll infl = 0x3F3F3F3F3F3F3F3FLL;
const int mod = 1e9 + 7, MM = 1e6+2;
int n, m, d[MM], s[MM], t[MM], dif[MM], a[MM];
bool chk(int x){
    cl(dif, 0);
    for(int i=1; i<=x; i++){
        dif[s[i]]+= d[i]; dif[t[i]+1]-=d[i];
    }
    for(int i=1; i<=n; i++){
        dif[i] += dif[i-1];
        if(dif[i] > a[i]) return false;
    }
    return true;
}
int main(){
    //freopen("test.txt", "r", stdin);
    ios::sync_with_stdio(0), cin.tie(0), cout.tie(0);
    cin >> n >> m;
    for(int i=1; i<=n; i++) cin >> a[i];
    for(int i=1; i<=m; i++) cin >> d[i] >> s[i] >> t[i];
    int lo = 1, hi = m, ans = m+1;
    while(lo <= hi){
        int mid = (lo + hi)/2;
        if(chk(mid)) lo = mid + 1;
        else ans = mid, hi = mid - 1;
    }
    if(ans > m) cout << "0\n";
    else cout << "-1\n" << ans << "\n";
}