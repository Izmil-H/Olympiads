#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int k; string s;
int dis(char a, char b){ return min(abs(a-b), 26-abs(a-b)); }
int main(){
    cin >> k >> s;
    for(char a ='a'; a<='z'; a++) {
        for(char b='a'; b<='z'; b++) {
            for(char c='a'; c<='z'; c++) {
                for(char d='a'; d<='z'; d++) {
                    if(dis(a, s[0]) + dis(b, s[1]) + dis(c, s[2]) + dis(d, s[3]) <= k) {
                        cout << a << b << c << d << "\n";
                    }
                }
            }
        }
    }
}