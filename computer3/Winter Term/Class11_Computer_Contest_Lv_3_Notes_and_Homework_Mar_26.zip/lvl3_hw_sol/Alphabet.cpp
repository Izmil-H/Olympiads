#include <bits/stdc++.h>
using namespace std;
string a = "abcdefghijklmnopqrstuvwxyz", b; int dp[52][52];
int main(){
    getline(cin, b);
    for(int i=1; i<=a.size(); i++)
        for(int j=1; j<=b.size(); j++)
            if(a[i-1] == b[j-1]) dp[i][j] = dp[i-1][j-1] + 1;
            else dp[i][j] = max(dp[i-1][j], dp[i][j-1]);
    printf("%d\n", 26 - dp[a.size()][b.size()]);
}