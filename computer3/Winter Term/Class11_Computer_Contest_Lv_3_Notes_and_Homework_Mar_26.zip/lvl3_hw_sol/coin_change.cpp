#include <bits/stdc++.h>
using namespace std;
int x, n;
int main(){
    cin >> x >> n;
    vector<int> num(x+1, 20000), coin(n); num[0]=0;
    for(int i=0; i<n; i++){
        cin >> coin[i];
        for(int j=coin[i]; j<=x; j++)
            num[j] = min(num[j], num[j-coin[i]]+1);
    }
    cout << num[x] << endl;
}