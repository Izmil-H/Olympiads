from sys import stdin
input = stdin.readline
n = int(input())
a = list(map(int, input().split()))
a.sort()
print(a[n//2])