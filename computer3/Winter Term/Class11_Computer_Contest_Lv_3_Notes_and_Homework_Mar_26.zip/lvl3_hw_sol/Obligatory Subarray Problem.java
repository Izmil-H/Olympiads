import java.util.*;
import java.io.*;
public class Main {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static PrintWriter pr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
	static StringTokenizer st;
	static int n, b, t, a[];
	public static void main(String[] args) throws IOException {
		n = readInt(); b = readInt(); t = readInt(); a = new int[n+1];
		for(int i=1; i<=n; i++) a[i] = readInt();
		System.out.println(fun(t) - fun(b-1));
	}
	static long fun(int lmt) {
		Deque<Integer> mx = new ArrayDeque(), mi = new ArrayDeque(); 
		long cnt = 0;
		for(int L=1, R=1; R<=n; R++) {
			while(!mx.isEmpty() && mx.peekLast() < a[R]) mx.pollLast();
			while(!mi.isEmpty() && mi.peekLast() > a[R]) mi.pollLast();
			mx.add(a[R]); mi.add(a[R]);
			while(!mx.isEmpty() && !mi.isEmpty() && mx.peek()-mi.peek()>lmt) {
				if(mx.peek() == a[L]) mx.poll();
				if(mi.peek() == a[L]) mi.poll();
				L++;
			}
			cnt += R - L + 1;
		}
		return cnt;
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}