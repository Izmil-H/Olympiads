#include <bits/stdc++.h>
using namespace std;
const int MM = 102;
int m, n, dp[MM][MM][2], g[MM][MM]; char ch;
int main(){
    while(scanf("%d %d", &m, &n) && m){
        memset(dp, 0, sizeof(dp));
        memset(g, 0, sizeof(g));
        for(int i=1; i<=m; i++){
            for(int j=1; j<=n; j++){
                scanf(" %c", &ch);
                if(ch == '*') g[i][j] = -1e9;
                else if(ch>='1' && ch<='9') g[i][j] = ch-'0';
            }
        }
        for(int i=m; i>=1; i--){
            dp[i][1][0] = dp[i+1][1][0] + g[i][1];
        }
        for(int j=2; j<=n; j++) {
            for(int i=m; i>=1; i--){
                dp[i][j][0] = max(max(dp[i][j-1][0], dp[i][j-1][1]), dp[i+1][j][0]) + g[i][j];
            }
            for(int i=1; i<=m; i++){
                dp[i][j][1] = max(max(dp[i][j-1][0], dp[i][j-1][1]), dp[i-1][j][1]) + g[i][j];
            }
        }
        printf("%d\n", max(dp[m][n][0], dp[m][n][1]));
    }
}