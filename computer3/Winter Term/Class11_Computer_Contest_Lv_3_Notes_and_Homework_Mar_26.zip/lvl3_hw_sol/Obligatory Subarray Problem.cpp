#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MM = 1e6+2;
int n, b, t, a[MM];
ll fun(int lmt){
    deque<int> mx, mi; ll cnt= 0;
    for(int l=1, r=1; r<=n; r++){
        while(!mx.empty() && mx.back() < a[r]) mx.pop_back();
        while(!mi.empty() && mi.back() > a[r]) mi.pop_back();
        mx.push_back(a[r]); mi.push_back(a[r]);
        while(!mx.empty() && !mi.empty() && mx[0]-mi[0] > lmt){
            if(mx[0] == a[l]) mx.pop_front();
            if(mi[0] == a[l]) mi.pop_front();
            l++;
        }
        cnt += r - l + 1;
    }
    return cnt;
}
int main(){
    ios::sync_with_stdio(0); cin.tie(0);
    cin >> n >> b >> t;
    for(int i=1; i<=n; i++) cin >> a[i];
    cout << fun(t) - fun(b-1) << endl;
}