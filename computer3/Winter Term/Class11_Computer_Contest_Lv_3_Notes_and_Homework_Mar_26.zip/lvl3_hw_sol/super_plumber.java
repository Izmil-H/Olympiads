import java.util.*;
import java.io.*;
public class Main {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static PrintWriter pr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException {
		while(true) {
			int n = readInt(), m = readInt();
			if(n==0 && m==0) break;
			char g[][] = new char[n][m]; int dp[][][] = new int[n][m][2];
			for(int i=0; i<n; i++) {
				g[i] = readLine().toCharArray();
				for(int j=0; j<m; j++) dp[i][j][0]= dp[i][j][1] = (int)-1e9;
			}
			dp[n-1][0][0] = get(g[n-1][0]);
			for(int i=n-2; i>=0; i--) {
				if(g[i][0] != '*') {
					dp[i][0][0] = dp[i+1][0][0] + get(g[i][0]);
				}
			}
			for(int j=1; j<m; j++) {
				for(int i=0; i<n; i++) {
					if(g[i][j] == '*') continue;
					dp[i][j][1] = Math.max(dp[i][j-1][0], dp[i][j-1][1]) + get(g[i][j]);
					if(i > 0) dp[i][j][1] = Math.max(dp[i][j][1], dp[i-1][j][1]+get(g[i][j]));
				}
				for(int i=n-1; i>=0; i--) {
					if(g[i][j] == '*') continue;
					dp[i][j][0] = Math.max(dp[i][j-1][0], dp[i][j-1][1]) + get(g[i][j]);
					if(i != n-1) dp[i][j][0] = Math.max(dp[i][j][0], dp[i+1][j][0] + get(g[i][j]));
				}
			}
			System.out.println(Math.max(dp[n-1][m-1][0], dp[n-1][m-1][1]));
		}
	}
	static int get(char c) {
		return c=='.'? 0: c-'0';
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}