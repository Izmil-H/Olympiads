from sys import stdin
input = stdin.readline
amount, n = int(input()), int(input())
dp = [float('inf')]*(amount + 1)
dp[0] = 0
for i in range(n):
    x = int(input())
    for j in range(x, amount+1):
        dp[j] = min(dp[j], dp[j-x]+1)
print(dp[amount])