#include <bits/stdc++.h>
using namespace std;
int N, K, a[102], dp[100002];
bool fun(int n){
    if(n == 0) return dp[n] = 0;
    if(dp[n] != -1) return dp[n];
    for(int i=1; i<=N; i++)
        if(n >= a[i] && !fun(n-a[i])) return dp[n] = 1;
    return dp[n] = 0;
}
int main(){
    scanf("%d %d", &N, &K); memset(dp, -1, sizeof(dp));
    for(int i=1; i<=N; i++) scanf("%d", &a[i]);
    printf("%s\n", fun(K)? "First": "Second");
}