#include <bits/stdc++.h>
using namespace std;
const int MM = 1e5+5;
int T, N, dp[MM], a[MM]; vector<int> prime; bool f[MM];
int main(){
    ios::sync_with_stdio(0); cin.tie(0);
    for(int i=2; i<MM; i++){
        if(!f[i]) {
            prime.push_back(i);
            for(int j=2*i; j<MM; j+=i) f[j] = 1;
        }
    }
    for(int i=3; i<MM; i++){
        for(int p : prime){
            if(p+1 > i) break;
            dp[i] |= !dp[i-p];
        }
    }
    for(cin >> T; T--; ){
        cin >> N;
        if(N <= 2) { cout << -1 << "\n"; continue; }
        for(int i=1; i<=N; i++) a[i] = i;
        int last = N;
        while(!dp[last]) last--;
        swap(a[last], a[N]); sort(a+last+1, a+N+1);
        for(int i=1; i<=N; i++) cout << a[i] << " \n"[i==N];
    }
}