import sys
input = sys.stdin.readline

def main():
    n, ans = int(input()), 0
    for i in range(n):
        ans ^= int(input())
    print(ans)

main()