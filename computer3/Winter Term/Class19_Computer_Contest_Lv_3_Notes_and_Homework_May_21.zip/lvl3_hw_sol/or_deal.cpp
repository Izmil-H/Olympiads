#include <bits/stdc++.h>
using namespace std;
long long N; int k;
int main(){
    for(scanf("%lld", &N); N; N>>=1) k++;
    for(k--; k>=0; k--) printf("1");
    printf("\n");
}