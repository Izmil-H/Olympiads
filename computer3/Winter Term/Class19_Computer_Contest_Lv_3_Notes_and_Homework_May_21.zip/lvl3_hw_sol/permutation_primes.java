import java.io.*;
import java.util.*;
public class Main {
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    static StringTokenizer st;
    public static void main(String args[]) throws IOException{
    	int mx = (int)1e5; boolean f[] = new boolean[mx+1];
    	f[0] = f[1] = true; List<Integer> p = new ArrayList();
    	for(int i=2; i<=mx; i++) {
    		if(!f[i]) {
    			p.add(i);
    			for(int j=2*i; j<=mx; j+=i) f[j] = true;
    		}
    	}
    	boolean dp[] = new boolean[mx+1];
    	for(int i=3; i<=mx; i++) {
    		for(int j : p) {
    			if(j + 1 > i) break;
    			if(!dp[i-j]) { dp[i] = true; break; }
    		}
    	}
    	for(int T = readInt(); T>0; T--) {
    		int n = readInt(), a[] = new int[n];
    		if(n <= 2) { System.out.println(-1); continue; }
    		for(int i=0; i<n; i++) a[i] = i+1;
    		int last = n;
    		while(!dp[last]) last--;
    		a[last-1] = n; a[n-1] = last;
    		Arrays.sort(a, last, n);
    		for(int i=0; i<n; i++) 
    			System.out.print(a[i] + (i==n-1? "\n": " "));
    	}
    }
    static String next() throws IOException {
        while (st == null || !st.hasMoreTokens())
            st = new StringTokenizer(br.readLine().trim());
        return st.nextToken();
    }
    static long readLong() throws IOException {
        return Long.parseLong(next());
    }
    static int readInt() throws IOException {
        return Integer.parseInt(next());
    }
    static double readDouble() throws IOException {
        return Double.parseDouble(next());
    }
    static String readLine() throws IOException {
        return br.readLine().trim();
    }
}
