import sys
input = sys.stdin.readline

def main():
    n = int(input())
    a = [0] * n
    for i in range(n):
        lst = list(map(int, input().split()))
        for j in range(n):
            a[i] |= lst[j]
    for x in a:
        print(x, end=' ')

main()