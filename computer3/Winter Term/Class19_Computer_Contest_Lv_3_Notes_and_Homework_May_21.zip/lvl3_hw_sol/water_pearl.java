import java.util.*;
import java.io.*;
import java.math.*;
public class homework {
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    static StringTokenizer st;
    public static void main(String[] args) throws IOException{
    	int c = readInt(), d = readInt(), e = readInt(), a = 0, b = 0, cnt = 1;
    	for(int i=30; i>=0; i--) {
    		if(((e>>i) & 1)!=0) { cnt<<=1; a=a<<1|1;  b=b<<1; }
    		else if((d>>i & 1) != 0) { a=a<<1|1; b=b<<1|1; }
    		else { a<<=1; b<<=1; }
    	}
    	if(!( (a|b)==c && (a&b)==d && (a^b)==e )) System.out.println(0);
    	else System.out.println(cnt);
    }
    static String next () throws IOException {
        while (st == null || !st.hasMoreTokens())
            st = new StringTokenizer(br.readLine().trim());
        return st.nextToken();
    }
    static long readLong () throws IOException {
        return Long.parseLong(next());
    }
    static int readInt () throws IOException {
        return Integer.parseInt(next());
    }
    static double readDouble () throws IOException {
        return Double.parseDouble(next());
    }
    static char readCharacter () throws IOException {
        return next().charAt(0);
    }
    static String readLine () throws IOException {
        return br.readLine().trim();
    }
}