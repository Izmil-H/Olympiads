#include <bits/stdc++.h>
using namespace std;
int N, a[1000][1000], row[1000];
int main(){
    scanf("%d", &N);
    for(int i=0; i<N; i++){
        for(int j=0; j<N; j++){
            scanf("%d", &a[i][j]);
            row[i] |= a[i][j];
        }
        printf("%d ", row[i]);
    }
}