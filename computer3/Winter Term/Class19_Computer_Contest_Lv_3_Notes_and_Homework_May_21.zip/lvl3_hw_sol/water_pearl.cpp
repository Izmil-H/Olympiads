#include <bits/stdc++.h>
using namespace std;
int C, D, E, cnt = 1, x, y;
int main(){
    scanf("%d %d %d", &C, &D, &E);
    for(int i=30; i>=0; i--){
        if((E>>i) & 1) { cnt*=2; x <<=1; y = y<<1|1; }
        else if((D>>i) & 1) { x = x<<1|1; y = y<<1|1;}
        else { x<<=1; y<<=1; }
    }
    if( (x|y) != C || (x&y) != D || (x^y) != E) printf("0\n");
    else printf("%d\n", cnt);
}