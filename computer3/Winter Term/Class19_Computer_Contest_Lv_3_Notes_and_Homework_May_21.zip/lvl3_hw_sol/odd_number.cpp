#include <stdio.h>
int n, ans, x;
int main(){
    for(scanf("%i", &n); n--; ){
        scanf("%i", &x);
        ans ^= x;
    }
    printf("%d\n", ans);
}