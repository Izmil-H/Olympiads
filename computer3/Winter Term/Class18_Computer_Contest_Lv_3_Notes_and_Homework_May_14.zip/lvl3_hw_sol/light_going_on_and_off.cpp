#include <bits/stdc++.h>
using namespace std;
int R, L, p[31]; unordered_set<int> s[31];
int main(){
    cin >> R >> L;
    for(int i=1; i<=R; i++){
        for(int j=1, x; j<=L; j++){
            cin >> x;   p[i] = p[i]<<1 | x;
        }
    }
    for(int i=1; i<=R; i++){
        s[i].insert(p[i]);
        for(int j: s[i-1]) s[i].insert( j ^ p[i] );
    }
    cout << s[R].size() << "\n";
}