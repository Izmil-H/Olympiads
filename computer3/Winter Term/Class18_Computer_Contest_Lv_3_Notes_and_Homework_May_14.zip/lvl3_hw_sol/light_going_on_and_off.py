import sys
input = sys.stdin.readline

def xor(a, b):
    c = ''
    for i in range(len(a)):
        c += '0' if a[i] == b[i] else '1'
    return c

R = int(input())
C = int(input())
light = ["".join(input().split()) for i in range(R)]
r1 = set()
r1.add(light[0])
for i in range(1, R):
    cur =  set()
    cur.add(light[i])
    for j in r1:
        cur.add( xor(j, light[i] )) 
    r1 = cur
print(len(r1))