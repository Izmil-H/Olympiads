def toBase10(x, base):
    val = 0
    lst = list(x)
    lst.reverse()
    for j in range(len(lst)):
        val += int(lst[j]) * (base ** j)
    return val

def toBaseX(x, bf):
    m = ''
    while x != 0:
        m += str(x % bf)
        x = x // bf
    return m

t = int(input())
for i in range(t):
    b1 = int(input())
    a = input()
    b2 = int(input())
    b = input()
    operand = input()
    bf = int(input())
    if i < t-1:
        blank = input()

    abase10 = toBase10(a, b1)
    bbase10 = toBase10(b, b2)
    finalbase10 = 0
    if operand == "+":
        finalbase10 = abase10 + bbase10
    elif operand == "-":
        finalbase10 = abase10 - bbase10
    elif operand == "*":
        finalbase10 = abase10 * bbase10
    else:
        finalbase10 = abase10 // bbase10
    print(int(toBaseX(finalbase10, bf)[::-1]))