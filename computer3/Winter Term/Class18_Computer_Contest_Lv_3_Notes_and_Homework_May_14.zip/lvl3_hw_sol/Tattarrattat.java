import java.io.*;
import java.util.*;
public class Main {
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    static StringTokenizer st;
    public static void main(String args[]) throws IOException{
    	for(int t=1; t<=5; t++) {
    		char s[] = readLine().toCharArray(); 
    		int n = s.length, dp[][] = new int[n][n];
    		for(int i=0; i<n; i++) dp[i][i] = 1;
    		for(int len=1; len<n; len++) {
    			for(int L=0, R=L+len; R<n; L++, R++) {
    				if(s[L] == s[R]) dp[L][R] = 2 + dp[L+1][R-1];
    				else dp[L][R] = Math.max(dp[L+1][R], dp[L][R-1]);
    			}
    		}
    		System.out.println(dp[0][n-1]);
    	}
    }
    static String next() throws IOException {
        while (st == null || !st.hasMoreTokens())
            st = new StringTokenizer(br.readLine().trim());
        return st.nextToken();
    }
    static long readLong() throws IOException {
        return Long.parseLong(next());
    }
    static int readInt() throws IOException {
        return Integer.parseInt(next());
    }
    static double readDouble() throws IOException {
        return Double.parseDouble(next());
    }
    static String readLine() throws IOException {
        return br.readLine().trim();
    }
}