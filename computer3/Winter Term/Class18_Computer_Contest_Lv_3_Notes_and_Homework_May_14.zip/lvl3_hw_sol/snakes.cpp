#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MM = 402;
int N, K, a[MM], mx, sum; ll dp[MM][MM];
int main(){
    //freopen("test.txt", "r", stdin);
    scanf("%d %d", &N, &K);
    memset(dp, 0x3f, sizeof(dp));
    for(int i=1; i<=N; i++){
        scanf("%d", &a[i]);
        mx = max(mx, a[i]);
        dp[i][0] = mx*i;  sum += a[i];
    }
    for(int i=1; i<=N; i++){
        for(int k=1; k<=K; k++){
            mx = a[i];
            for(int j=i-1; j>=0; j--){
                dp[i][k] = min(dp[i][k], dp[j][k-1] + mx * (i-j));
                mx = max(mx, a[j]);
            }
        }
    }
    printf("%lld\n", dp[N][K] - sum);
}