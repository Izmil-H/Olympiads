#include <stdio.h>
#include <string.h>
using namespace std;

int main()
{
    //freopen("s5.4.in", "r", stdin);
    int move[5][4] = {{2, 1, 0, 2}, {1, 1, 1, 1}, {0, 0, 2, 1}, {0, 3, 0, 0}, {1, 0, 0, 1}};
    bool win[31][31][31][31];

    memset(win, 0, sizeof(win));
    for(int a=0; a<31; a++)
        for(int b=0; b<31; b++)
            for(int c=0; c<31; c++)
                for(int d=0; d<31; d++)
                    for(int m=0; m<5; m++)
                        if(a>=move[m][0] && b>=move[m][1] && c>=move[m][2] && d>=move[m][3])
                            if(!win[a-move[m][0]][b-move[m][1]][c-move[m][2]][d-move[m][3]])
                                win[a][b][c][d] = 1;
    int t, a, b, c, d;
    scanf("%d", &t);
    while(t--)
    {
        scanf("%d %d %d %d", &a, &b, &c, &d);
        if(win[a][b][c][d])
            printf("Patrick\n");
        else
            printf("Roland\n");
    }

    return 0;
}