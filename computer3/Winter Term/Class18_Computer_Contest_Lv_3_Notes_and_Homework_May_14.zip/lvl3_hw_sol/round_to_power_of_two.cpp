#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int main(){
    for(int t=1, n; t<=5; t++){
        cin >> n;  int k = log2(n), x = 1<<k, y = 1<<k+1;
        cout << (abs(x-n) < abs(y-n)? x: y) << endl;
    }
}