#include <iostream>
#include <string>
#include <stdio.h>
#include <stdlib.h>
using namespace std;
int t, m, n1, n2, b1, b2, bf, ans;
char op, buff[35];
string st1, st2;
int toDecimal(int b, string str)
{
    int n=0, base=1;
    for(int i=str.size()-1; i>=0; i--){
        n+=(str[i]-'0')*base;
        base*=b;
    }
    return n;
}

int main()
{
    cin>>t;
    while(t--){
        cin>>b1>>st1>>b2>>st2>>op>>bf;
        n1=toDecimal(b1, st1);
        n2=toDecimal(b2, st2);
        if(op=='+') ans=n1+n2;
        else if(op=='-') ans=n1-n2;
        else if(op=='*') ans=n1*n2;
        else if(op=='/') ans=n1/n2;
        for(m=0; ans>0; m++, ans/=bf)
            buff[m]=ans%bf;
        for(m--; m>=0; m--)
            cout<<(int)buff[m];
        cout<<endl;
    }
}