import java.io.*;
import java.util.*;
public class Main {
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    static StringTokenizer st;
    public static void main(String args[]) throws IOException{
    	int n = readInt(), k = readInt(), a[] = new int[n];
    	boolean dp[] = new boolean[k+1];
    	for(int i=0; i<n; i++) {
    		a[i] = readInt();
    	}
    	for(int i=1; i<=k; i++) {
    		boolean flag = false;
    		for(int j=0; j<n; j++) {
    			if(i >= a[j] && !dp[i-a[j]]) { flag = true; break; }
    		}
    		dp[i] = flag;
    	}
    	System.out.println(dp[k]? "First" : "Second");
    }
    static String next() throws IOException {
        while (st == null || !st.hasMoreTokens())
            st = new StringTokenizer(br.readLine().trim());
        return st.nextToken();
    }
    static long readLong() throws IOException {
        return Long.parseLong(next());
    }
    static int readInt() throws IOException {
        return Integer.parseInt(next());
    }
    static double readDouble() throws IOException {
        return Double.parseDouble(next());
    }
    static String readLine() throws IOException {
        return br.readLine().trim();
    }
}