import java.io.*;
import java.util.*;
public class Main {
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    static StringTokenizer st;
    public static void main(String args[]) throws IOException{
    	int N = readInt(), K = readInt(), a[] = new int[N+1], sum = 0;
    	int dp[][] = new int[N+1][K+1], mx = 0;
    	for(int i=1; i<=N; i++) {
    		a[i] = readInt(); mx = Math.max(mx, a[i]);
    		sum += a[i]; dp[i][0] = mx*i;
    	}
    	for(int i=1; i<=N; i++) {
    		for(int k=1; k<=K; k++) {
    			mx = a[i];  dp[i][k] = (int)1e9;
    			for(int j=i-1; j>=0; j--) {
    				dp[i][k] = Math.min(dp[i][k], dp[j][k-1] + mx*(i-j));
    				mx = Math.max(mx, a[j]);
    			}
    		}
    	}
    	System.out.println(dp[N][K] - sum);
    }
    static String next() throws IOException {
        while (st == null || !st.hasMoreTokens())
            st = new StringTokenizer(br.readLine().trim());
        return st.nextToken();
    }
    static long readLong() throws IOException {
        return Long.parseLong(next());
    }
    static int readInt() throws IOException {
        return Integer.parseInt(next());
    }
    static double readDouble() throws IOException {
        return Double.parseDouble(next());
    }
    static String readLine() throws IOException {
        return br.readLine().trim();
    }
}