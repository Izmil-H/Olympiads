#include <iostream>
#include <string>
#include <algorithm>
using namespace std;
int a, b, base; string str1;
int toDecimal(string str, int base){
    int ans=0;
    for(int t=0; t<str.size(); t++)
        ans=ans*base+str[t]-'0';
    return ans;
}
string convert(int num, int base){
    string tmp("");
    while(num){
        tmp += (char)(num%base+'0');
        num /=base;
    }
    reverse(tmp.begin(), tmp.end());
    return tmp;
}
int main(){
    for(int i=0; i<5; i++){
        cin >> str1 >> base;
        a = toDecimal(str1, base);
        cin >> str1 >> base;
        b = toDecimal(str1, base);
        cin >> base;
        cout << convert(a*b, base) << endl;
    }
}